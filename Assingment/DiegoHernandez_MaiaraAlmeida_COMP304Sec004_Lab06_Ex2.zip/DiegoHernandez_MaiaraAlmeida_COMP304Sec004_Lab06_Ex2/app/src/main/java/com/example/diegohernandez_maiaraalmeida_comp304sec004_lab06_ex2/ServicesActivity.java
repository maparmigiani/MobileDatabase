package com.example.diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Date;

public class ServicesActivity extends AppCompatActivity {
    private TextView textView, textViewNumbersCalled;
    EditText editTextDate;
    //replace with your package name
    public static final String INFO_INTENT ="diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2.INFO_UPDATE";
    public static final String NUMBERS_CALLED = "diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2.NUMBERS_CALLED";
    public static final String START_DATE = "diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2.START_DATE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);
        textView = (TextView) findViewById(R.id.textView);
        textViewNumbersCalled = findViewById(R.id.textViewNumbersCalled);
        editTextDate = findViewById(R.id.editTextDate);
    }
    @Override
    public void onResume()
    {
        super.onResume();
        //This needs to be in the activity that will end up receiving the broadcast
        registerReceiver(receiver, new IntentFilter(INFO_INTENT));
    }
    //
    public void startService(View view) {
        startService(new Intent(getBaseContext(), SimpleService.class));
    }
    public void stopService(View view) {
        stopService(new Intent(getBaseContext(),
                SimpleService.class));
    }

    //This will handle the broadcast
    public BroadcastReceiver receiver = new BroadcastReceiver() {
        //@Override
        public void onReceive(Context context, Intent intent) {
        //textView.setText("Here");
            String action = intent.getAction();
            if (action.equals(SimpleService.INFO_INTENT)) {
                String info = intent.getStringExtra(INFO_INTENT);
                String numbersCalled = String.valueOf(intent.getIntExtra(NUMBERS_CALLED,-1));
                textView.setText(info);

                Date d = new Date();
                d.setTime(intent.getLongExtra(START_DATE, -1));
                Log.i("Date", String.valueOf(intent.getLongExtra(START_DATE, -1)));
                editTextDate.setText(d.toString());
                textViewNumbersCalled.setText(numbersCalled);

            }
        }
    };
}