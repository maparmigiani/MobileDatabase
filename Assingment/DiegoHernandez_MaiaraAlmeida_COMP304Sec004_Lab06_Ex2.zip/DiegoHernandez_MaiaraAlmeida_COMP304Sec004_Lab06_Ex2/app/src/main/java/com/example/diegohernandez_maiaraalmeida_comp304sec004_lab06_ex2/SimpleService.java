package com.example.diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.io.Console;
import java.util.Calendar;
import java.util.Date;

public class SimpleService extends Service {
    public static final String INFO_INTENT = "diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2.INFO_UPDATE";
    public static final String NUMBERS_CALLED = "diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2.NUMBERS_CALLED";
    public static final String START_DATE = "diegohernandez_maiaraalmeida_comp304sec004_lab06_ex2.START_DATE";
    private double time=0;
    private int numbersCalled=0;
    public SimpleService() {
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // We want this service to continue running until it is explicitly
        // stopped, so return sticky.
        Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show();
        Date currentTime = Calendar.getInstance().getTime();
        long mills = currentTime.getTime();
        Log.i("Current Time", currentTime.toString());

        numbersCalled++;
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(INFO_INTENT);
        broadcastIntent.putExtra(NUMBERS_CALLED,numbersCalled);
        broadcastIntent.putExtra(START_DATE,mills);
        broadcastIntent.putExtra(INFO_INTENT,"Hello there! A simple service is sending this message to you !");
        this.sendBroadcast(broadcastIntent);



        //
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        numbersCalled=0;
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(INFO_INTENT);
        broadcastIntent.putExtra(NUMBERS_CALLED,numbersCalled);
        this.sendBroadcast(broadcastIntent);
        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();
    }
}